---
name: Feature request
about: Are we missing your favorite feature?
title: ''
labels: 'priority 4: wishlist, type: feature request'
assignees: ''

---

**Is your feature request related to a problem? Please describe.**
There is a better player for mac users than mpv.
It's called iina and is a mpv frontend written in swift.
It bugs me that I can't use it yet.

**Describe the solution you'd like**
Please add iina, maybe through a `-i` flag analogous to the vlc `-v` flag

**Describe alternatives you've considered**
Maybe support any player string by the user.
But I assume thats drastically more difficult.

**Additional context**
iina is just an mpv frontend and accepts its flags.
Needless to say it can play urls.
