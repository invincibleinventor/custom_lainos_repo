{-# LANGUAGE OverloadedStrings #-}

module Main where

import           AddProgram
import           Data.Text
import           Data.Text.ANSI

main :: IO ()
main = saveProgram
